// Simple form submission handling
document.getElementById("contactForm").addEventListener("submit", function(e) {
  e.preventDefault();
  
  const name = document.getElementById("name").value;
  const response = document.getElementById("response");

  response.textContent = `Thank you, ${name}! Your message has been sent successfully.`;
  
  this.reset();
});